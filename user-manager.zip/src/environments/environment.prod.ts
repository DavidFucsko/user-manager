export const environment = {
  production: true,
  user_endpoint: 'https://jsonplaceholder.typicode.com/users'
};
