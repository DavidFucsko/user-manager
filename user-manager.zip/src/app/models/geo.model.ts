export class Geo {
    lat: string;
    lng: string;
    constructor() {
        this.lat = '';
        this.lng = '';
    }
}
