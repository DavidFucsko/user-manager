export class Company {
    name: string;
    catchPhrase: string;
    bs: string;

    constructor() {
        this.name = '';
        this.catchPhrase = '';
        this.bs = '';
    }
}
